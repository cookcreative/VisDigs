=== Visdigs ===
Requires at least: 5.3
Tested up to: 5.4
Requires PHP: 7.2
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Creates an interfaces to manage digs for a theatre environment. 

== Description ==
Creates an interfaces to manage digs. 
- Creates and Password protects a post type \'digs\'. 
- Password protects Meta info. 
- Blocks post content and meta from appearing around the rest of the Wordpress website - Only allows single, page and admin to view the post type.